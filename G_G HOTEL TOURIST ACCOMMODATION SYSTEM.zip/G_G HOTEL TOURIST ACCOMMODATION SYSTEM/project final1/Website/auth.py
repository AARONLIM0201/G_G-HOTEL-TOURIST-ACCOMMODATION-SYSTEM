from flask import Blueprint,render_template,request,flash,redirect,url_for
from werkzeug.security import generate_password_hash, check_password_hash
from .dbmodels import User,Roominfo,Booking,Roomservice,Payment,Aadmin
from .import db
import smtplib
import random
import string
import re
from flask import session
from datetime import datetime

#Define auth Blueprint
auth = Blueprint('auth',__name__)

@auth.route('/homepage', methods=['GET', 'POST'])
def homepage():
    return render_template('homepage.html')


@auth.route("/login", methods=['GET','POST']) # Route decorator for the login endpoint
def login():
    if request.method == 'POST': # Check if the request method is POST
        email = request.form.get('email') # Retrieve the value of the 'email' field from the form
        password = request.form.get('password') # Retrieve the value of the 'password' field from the form
      

        admin =Aadmin.query.filter_by(username=email).first() # Query the database for an admin user with the provided email
        if admin: # If an admin user with the provided email exists
            if password ==admin.password : # if the provided password matches the admin's password
                return redirect(url_for('pages.adminmenu')) # Redirect to the admin menu page
            else:
                flash('Incorrect password, try again.', category='error') # Display an error flash message
                return render_template("login.html") # Render the login page template again
        
        user = User.query.filter_by(email=email).first() # Query the database for a regular user with the provided email

        
        if user: # if the provided email exists
            if 'random_password' in session and session['email'] == user.email: # Check if there is a temporary password stored in the session and if it matches the user's email
                # Check if the temporary password matches
                if password is not None and check_password_hash(user.password, password): # Check if the provided password matches the user's password

                    # Clear the temporary password from the session
                    session.pop('random_password', None)
                    session.pop('email', None)

                    return redirect(url_for('pages.usermenu'))
                else:
                    flash('Incorrect password, try again.', category='error')
            else:
                if password is not None and check_password_hash(user.password, password):
                    return redirect(url_for('pages.usermenu'))
                else:
                    flash('Incorrect password, try again.', category='error')
        else:
            flash('Email address not found.', category='error')

    return render_template('login.html')



@auth.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form.get('email')
        newpassword = request.form.get('newpassword')
        repassword = request.form.get('repassword')
        # Define a list of validations as tuples, each containing a condition and an error message
        validations = [
            (email is not None and len(email) < 7, 'Email must be greater than 6 characters.'),
            (newpassword != repassword, 'Password does not match.'),
            (newpassword is None or len(newpassword) < 6, 'Password must be more than 5 characters.'),
            (newpassword is not None and not re.search(b'[a-z]', newpassword.encode()), 'Password must contain at least one lowercase letter.'),
            (newpassword is not None and not re.search(b'[A-Z]', newpassword.encode()), 'Password must contain at least one uppercase letter.')
        ]
        # Iterate over the validations and check each condition
        for condition, error_message in validations:
            if condition:
                flash(error_message, category='error')
                break # Break the loop if a condition fails
        else:
            user = User.query.filter_by(email=email).first()
            if user:
                flash('Email already exists.', category='error')
            elif newpassword is not None:
                hashed_password = generate_password_hash(newpassword, method='sha256') #If the user doesn't exist,
                # hashes the password using the generate_password_hash function and creates a new user object.
                new_user = User(email=email, password=hashed_password)
                db.session.add(new_user) # Add the new user to the session
                db.session.commit() # Commit the changes to the database
                flash('Account created!', category='success')
                return redirect(url_for('auth.login'))
    
    return render_template("register.html")


def send_email(sender_email, receiver_email, subject, message, smtp_server, smtp_port, username, password):
    # Create the email content
    email_content = f"Subject: {subject}\n\n{message}"

    # Connect to the SMTP server
    with smtplib.SMTP(smtp_server, smtp_port) as server:
        server.starttls()
        server.login(username, password)
        server.sendmail(sender_email, receiver_email, email_content)

@auth.route('/forgotpassword',methods=['GET', 'POST'])
def forgotpassword():
    if request.method == 'POST':
        email = request.form.get('email')

        user = User.query.filter_by(email=email).first()

        if user:
            # Generate a random password
            random_password = ''.join(random.choices(string.ascii_letters + string.digits, k=8))

            # Update the user's password in the database
            user.password = generate_password_hash(random_password)
            db.session.commit()

            # Send the random password via email
            sender_email = "projectpython406@gmail.com"
            receiver_email = email
            subject = "Password Reset"
            message = f"Your new password is: {random_password}. Please log in and change it."
            smtp_server = "smtp.gmail.com"
            smtp_port = 587
            username = "projectpython406@gmail.com"
            password = "pfbdxnpkoijhiihx"
            send_email(sender_email, receiver_email, subject, message, smtp_server, smtp_port, username, password)

            flash('A new password has been sent to your email address. Please check your email and log in.', category='success')
            return redirect(url_for('auth.login'))
        else:
            flash('Email address not found.', category='error')

    return render_template('forgotpassword.html')

@auth.route('/user_changepassword',methods=['GET','POST'])
def user_changepassword():
    while True:
            if request.method == 'POST':
                email = request.form.get('email')
                current_password = request.form.get('current_password')
                new_password = request.form.get('new_password')
                confirm_password = request.form.get('confirm_password')

                user = User.query.filter_by(email=email).first()

                if user:
                    if current_password is not None and check_password_hash(user.password, current_password):
                        if new_password != confirm_password:
                            flash('New password and confirm password do not match.', category='error')
                        elif new_password is not None and len(new_password) < 6:
                            flash('Password must be at least 6 characters long.', category='error')
                        else:
                            # Update the user's password in the database
                            if new_password is not None:
                                user.password = generate_password_hash(new_password)
                                db.session.commit()
                                flash('Password updated successfully.', category='success')
                                return render_template('user_changepassword.html')
                    else:
                        flash('Incorrect current password.', category='error')
                else:
                    flash('Email address not found.', category='error')
            else:
                break  # Exit the loop if request method is not POST

    return render_template('user_changepassword.html')


@auth.route('/usermenu', methods=['GET', 'POST'])
def usermenu():
    return render_template('usermenu.html')


@auth.route('/booking', methods=['GET', 'POST'])
def booking():
    # Retrieve all rows from the Roominfo table
    rows = Roominfo.query.all()

    if request.method == 'POST':
        # Extract form data
        name = request.form.get('name')
        ic = request.form.get('IC')
        gender = request.form.get('gender')
        phonenum = request.form.get('phonenum')
        roomtype = request.form.get('roomtype')
        checkin_str = request.form.get('checkin')
        checkout_str = request.form.get('checkout')
        room_no = request.form.get('room_no')
        roomservice = request.form.get('roomservice')
        
        if not name:
            flash('Please Enter your Name', category='error')
            return render_template('booking.html', rows=rows)
        elif ic is None or len(ic) != 12:
            flash('Please enter a valid IC number', category='error')
            return render_template('booking.html', rows=rows)
        elif phonenum is None or len(phonenum) < 10:
            flash('Please enter a valid phone number', category='error')
            return render_template('booking.html', rows=rows)
        elif not roomtype:
            flash('Please select room type', category='error')
            return render_template('booking.html', rows=rows)
        elif not checkin_str  or not checkout_str:
            flash('Please select your Checkin and Checkout date', category='error')
            return render_template('booking.html', rows=rows)
        elif checkin_str > checkout_str:
            flash('Checkin date is earlier than Checkout date. Please try again', category='error')
            return render_template('booking.html', rows=rows)
        else:
            # Convert checkin and checkout strings to Python date objects
            checkin = datetime.strptime(checkin_str, '%Y-%m-%d').date() if checkin_str else None
            checkout = datetime.strptime(checkout_str, '%Y-%m-%d').date() if checkout_str else None

            # Create a new booking instance
            booking = Booking(
                name=name,
                ic=ic,
                gender=gender,
                phonenum=phonenum,
                roomtype=roomtype,
                checkin=checkin,
                checkout=checkout,
                room_no=room_no,
                roomservice=roomservice
            )

            # Add and commit the new booking to the database
            db.session.add(booking)
            db.session.commit()

            return redirect(url_for('auth.bill'))
    
    else:
        # Retrieve all rows from the Roominfo table
        rows = Roominfo.query.all()
        return render_template('booking.html', rows=rows)


@auth.route('/roomservice', methods=['GET', 'POST'])
def roomservice():
    rows = Roomservice.query.all() # Fetch all rows from the Roomservice table
    return render_template('roomservice.html', rows=rows) # Pass the rows as a parameter

@auth.route('/bill', methods=['GET', 'POST'])
def bill():
    if request.method == 'POST':
        # Extract form data
        room_no = request.form.get('room_no')
        roomservice = request.form.get('roomservice')

        # Get the room price from the Roominfo table
        room_info = Roominfo.query.filter_by(room_no=room_no).first()
        room_price = int(room_info.price) if room_info else 0

        # Get the room service price from the Roomservice table
        room_service = Roomservice.query.get(roomservice)
        room_service_price = int(room_service.price) if room_service else 0

        # Calculate the duration of stay
        booking = Booking.query.filter_by(room_no=room_no).first()
        duration = (booking.checkout - booking.checkin).days if booking else 0

        # Calculate the total price by multiplying with the duration
        total_price = (room_price + room_service_price) * duration

        # Calculate the service tax (6% of service tax)
        service_tax = total_price * 0.06

        # Calculate the final price including service tax
        final_price = total_price + service_tax

        return render_template('bill.html', total_price=total_price, service_tax=service_tax, final_price=final_price)
    else:
        return render_template('bill.html')
    
    
@auth.route('/attraction')
def attraction():
    return render_template('attraction.html')


@auth.route('/payment', methods=['GET', 'POST'])
def payment():
    if request.method == 'POST':
        payname = request.form.get('payname')
        referenceid = request.form.get('referenceid')

        payment = Payment( # Create a new Payment object with the provided data
            payname=payname,
            referenceid=referenceid
        )
        db.session.add(payment) # Add the payment object to the database session
        db.session.commit() # Commit the changes to the database
        return redirect(url_for('pages.usermenu'))

    return render_template('payment.html')


@auth.route('/quit')
def quit():
    return render_template("quit.html")


@auth.route('/adminmenu')
def adminmenu():
    return render_template("adminmenu.html")


@auth.route('/updateinfo', methods=['GET'])
def updateinfo():
    # Retrieve all rows from the Roominfo table
    rows = Roominfo.query.all()
    return render_template("updateinfo.html", rows=rows)


@auth.route('/roominfo/add', methods=['GET', 'POST'])
def add_roominfo():
    if request.method == 'POST':
        # Retrieve the form data
        room_no = request.form['room_no']
        beds = request.form['beds']
        price = request.form['price']
        status = request.form['status']
        new_roominfo = Roominfo(room_no=room_no, beds=beds, price=price, status=status)
        db.session.add(new_roominfo)
        db.session.commit()
        return redirect(url_for('auth.updateinfo'))
    return render_template('add_roominfo.html')


@auth.route('/roominfo/edit/<int:room_id>', methods=['GET', 'POST'])
def edit_roominfo(room_id):
    # Retrieve the Roominfo object with the given room_id
    room = Roominfo.query.get(room_id)
    if request.method == 'POST':
        # Update the room object with the form data
        room.room_no = request.form['room_no']
        room.beds = request.form['beds']
        room.price = request.form['price']
        room.status = request.form['status']
        db.session.commit()
        return redirect(url_for('auth.updateinfo'))
    return render_template('edit_roominfo.html', room=room)


@auth.route('/roominfo/delete/<int:room_id>', methods=['GET', 'POST'])
def delete_roominfo(room_id):
    room = Roominfo.query.get(room_id)
    db.session.delete(room) # Delete the room object from the session
    db.session.commit()
    return redirect(url_for('auth.updateinfo'))


@auth.route('/paymenthistory')
def paymenthistory():
    payments = Payment.query.all() # Fetch all payment records from the database
    return render_template("paymenthistory.html",payments=payments)


@auth.route('/checkbooking')
def checkbooking():
    bookings = Booking.query.all()
    return render_template("checkbooking.html",bookings=bookings)


@auth.route('/customerlookup',methods=['GET'])
def customerlookup():
    bookings = Booking.query.all()
    return render_template("customerlookup.html", bookings=bookings)


@auth.route('/cancelbooking')
def cancelbooking():
    bookings = Booking.query.all()
    return render_template("cancelbooking.html",bookings=bookings)


@auth.route('/cancelbooking/delete/<int:booking_id>', methods=['GET', 'POST'])
def delete_booking(booking_id):
    booking = Booking.query.get(booking_id)
    if booking:
        db.session.delete(booking) # Delete the booking record from the database
        db.session.commit()
        flash('Booking deleted successfully!', category='success')
        return redirect(url_for('auth.cancelbooking'))
    else:
        flash('Booking not found.', category='error')
    return redirect(url_for('auth.cancelbooking'))


@auth.route('/changepassword', methods=['GET', 'POST'])
def changepassword():
    if request.method == 'POST':
        new_password = request.form['new_password']
        confirm_password = request.form['confirm_password']

        if new_password == confirm_password:
            admin = Aadmin.query.filter_by(username='admin@gmail.com').first() # Retrieve the admin record from the database
            if admin:
                admin.password = new_password # Update the admin's password with the new password
                db.session.commit()
                flash('Password successfully updated!', category='success')
                return redirect(url_for('auth.changepassword'))
            else:  
                return render_template('changepassword.html')
        else:
            flash('Password does not match! Please try again', category='error')
            return redirect(url_for('auth.changepassword'))

    return render_template('changepassword.html')