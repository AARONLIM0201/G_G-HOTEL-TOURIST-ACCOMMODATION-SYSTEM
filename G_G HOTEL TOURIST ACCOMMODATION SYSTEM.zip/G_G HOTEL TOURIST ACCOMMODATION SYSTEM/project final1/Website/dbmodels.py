from .import db
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from sqlalchemy.sql import func
from datetime import datetime


#Create database modal
class Note(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    data = db.Column(db.String(10000))
    date = db.Column(db.DateTime(timezone=True), default=func.now())
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))

class User(db.Model,UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(150),unique=True, nullable=False)
    password = db.Column(db.String(150))


class Roominfo(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    room_no = db.Column(db.String(150), nullable=False)
    beds = db.Column(db.String(150))
    price = db.Column(db.String(150))
    status = db.Column(db.String(150))

    def __repr__(self):
        return f"<Roominfo(id={self.id}, room_no='{self.room_no}', beds='{self.beds}', price='{self.price}', status='{self.status})>"

class Booking(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150),nullable=False)
    ic = db.Column(db.String(150),nullable=False)
    gender = db.Column(db.String(10), nullable=False)
    phonenum = db.Column(db.String(150),nullable=False)
    roomtype = db.Column(db.String(10), nullable=False)
    checkin = db.Column(db.Date, nullable=False)
    checkout = db.Column(db.Date, nullable=False)
    room_no = db.Column(db.String(150),nullable=False)
    roomservice = db.Column(db.String(10), nullable=False)


    def __repr__(self):
        return f"<Booking(id={self.id}, name='{self.name}', ic='{self.ic}', gender='{self.gender}', phonenum='{self.phonenum}', roomtype='{self.roomtype}', checkin='{self.checkin}', checkout='{self.checkout}', room_no='{self.room_no}',roomservice='{self.roomservice})>"

class Roomservice(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    room_service = db.Column(db.String(150), nullable=False)
    price = db.Column(db.String(150), nullable=False)

    def __repr__(self):
        return f"<Roomservice(id={self.id}, room_no='{self.room_service}', price='{self.price}')>"
    
class Payment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    payname = db.Column(db.String(150), nullable=False)
    referenceid = db.Column(db.String(150), nullable=False)

    def __repr__(self):
        return f"<Payment(id={self.id}, payname='{self.payname}', referenceid='{self.referenceid}')>"

class TemporaryPassword(db.Model):
    # Define the table columns
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(120), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        # Define the string representation of the object
        return f"TemporaryPassword(email='{self.email}', password='{self.password}', created_at='{self.created_at}')"
        # Returns a formatted string containing the email, password, and creation timestamp 

class Aadmin(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150))
    password = db.Column(db.String(150))

    def __repr__(self):
        return f"<Admin(id={self.id}, username='{self.username}')>"