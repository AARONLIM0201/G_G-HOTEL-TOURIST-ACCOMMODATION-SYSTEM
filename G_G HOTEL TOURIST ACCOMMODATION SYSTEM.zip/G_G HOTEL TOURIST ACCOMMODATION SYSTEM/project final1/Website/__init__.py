from msilib.schema import AdminExecuteSequence
from flask import Flask
from flask_sqlalchemy import SQLAlchemy


db = SQLAlchemy()

def create_app(): #initializes the Flask application and sets the necessary configurations
    app = Flask(__name__)
    app.config['SECRET_KEY'] = '12345'  #configuration for session security.
    app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///users.db' #configuration to specify the SQLite database URI
    db.init_app(app) #initializes the SQLAlchemy extension with the Flask application

    from .pages import pages
    from .auth import auth

    # registers the blueprints with the Flask application, specifying their URL prefixes
    app.register_blueprint(pages,url_prefix='/')
    app.register_blueprint(auth,url_prefix='/')

    with app.app_context():
        db.create_all() #creates all the database tables within the application context
    return app


# Function to create and configure the Flask application
def Roominfo():
    Roominfo = Flask(__name__)
    Roominfo.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///roominfo.db'
    Roominfo.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    db.init_app(Roominfo)
    with Roominfo.app_context():
        db.create_all()
    db.session.commit()
    return Roominfo

def Booking():
    Booking = Flask(__name__)
    Booking.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///booking.db'
    Booking.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    db.init_app(Booking)
    # Create all the necessary database tables
    with Booking.app_context():
        db.create_all()
        # Commit any changes to the database
    db.session.commit()
    return Booking

def Roomservice():
    Roomservice = Flask(__name__)
    Roomservice.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///roomservice.db' # Set the database URI for the SQLite database
    Roomservice.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False # Disable modification tracking
    db.init_app(Roomservice)
    with Roomservice.app_context():
        db.create_all()
    db.session.commit()
    return Roomservice

def Payment():
    Payment = Flask(__name__)
    Payment.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///payment.db'
    Payment.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    db.init_app(Payment)
    with Payment.app_context():
        db.create_all()
    db.session.commit()
    return Payment