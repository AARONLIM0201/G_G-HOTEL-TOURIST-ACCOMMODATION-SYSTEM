from flask import Blueprint,render_template

#Define pages Blueprint
pages = Blueprint('pages',__name__)

@pages.route('/')
def homepage():
    return render_template("homepage.html")

@pages.route('/usermenu')
def usermenu():
    return render_template("usermenu.html")

@pages.route('/adminmenu')
def adminmenu():
    return render_template("adminmenu.html")