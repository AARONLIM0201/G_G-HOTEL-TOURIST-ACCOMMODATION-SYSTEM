# *********************************************************
# Program: G_G HOTEL TOURIST ACCOMMODATION SYSTEM
# Course: PSP0201 MINI IT PROJECT
# Tutorial Section: TC6L Group: G6
# Trimester: 2220
# Year: 2022/23 Trimester 2
# Member_1: 1211108846 | VENICE GOH KIT YEE
# Member_2: 1211108620 | WONG LEXUAN
# Member_3: 1211111818 | AARON LIM CJUN SHIEN
# Member_4: 1211108527 | WONG HUI TING

# **************** TASK DISTRIBUTION **********************
# Member_1: Booking, Registration, Make_Payment, Show_Room_Services
# Member_2: User_Login, Forgot_Password, User_Change_Password
# Member_3: User_Check_Bills, Admin_Update_Info, Check_Payment_History, Customer_Lookup
# Member_4: Admin_Login, Admin_Change_Password, Check_Booking, Cancel_Booking
# *********************************************************

from flask import Flask
from Website import create_app
from flask_sqlalchemy import SQLAlchemy

app = create_app() # Create an instance of the Flask application

if __name__ == '__main__':
    app.run(debug=True) # Start the Flask development server with debug mode enabled